#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ioctl.h>
#include<termios.h>

int	PAGELEN;
int	LINELEN;
int 	FILELEN;
int     FILEBYTE;
void do_more(FILE *);
int see_more(FILE *,int readedBytes);

int main( int ac , char *av[] )
{
	FILE	*fp;

	if ( ac == 1 )
		do_more( stdin );
	else
		while ( --ac )
		{
			if ( (fp = fopen( *++av , "r" )) != NULL )
			{
				FILELEN=lseek(fileno(fp),0L,SEEK_END);
				lseek(fileno(fp),0L,SEEK_SET);	
				do_more( fp ) ; 
				fclose( fp );
			}
			else
				exit(1);
		}
	return 0;
}

void do_more( FILE *fp )
{

	FILE	*fp_tty;
	fp_tty = fopen( "/dev/tty", "r" );
	if ( fp_tty == NULL )
		exit(1);
	struct winsize size;
	ioctl(fileno(fp_tty),TIOCGWINSZ,&size);
	PAGELEN=size.ws_row;
	LINELEN=size.ws_col;
	char	line[LINELEN];
	int	num_of_lines = 0;
	int	see_more(FILE *,int readedBytes), reply;

	int readedBytes=0;

	while ( fgets( line, LINELEN, fp ) ){
		readedBytes+=strlen(line);
		if ( num_of_lines == PAGELEN ) {
			reply = see_more(fp_tty,readedBytes);
			if ( reply == 0 )
				break;
			num_of_lines -= reply;
		}
		if ( fputs( line, stdout )  == EOF )
		{
			printf("\n");
			exit(1);	
		}
		num_of_lines++;
	}
}

int see_more(FILE *cmd,int readedBytes)
{
	int	c;
	if(FILELEN==0)
		return 0;
	int percent=readedBytes*100/FILELEN; 
	printf("\033[7m more %d% \033[m",percent);
	struct termios oldt,newt;
	tcgetattr(fileno(cmd),&oldt);
	newt=oldt;
	newt.c_lflag&=~(ECHO|ICANON);
	tcsetattr(fileno(cmd),TCSANOW,&newt);
	while( (c=getc(cmd)) != EOF )
	{
		int result=0;
		if ( c == 'q' )
			result= 0;
		if ( c == ' ' )
			result= PAGELEN;
		if ( c == '\n' )
			result= 1;
		tcsetattr(fileno(cmd),TCSANOW,&oldt);		
		return result;
		
	}
	return 0;
}
