#include<stdio.h>
#include<signal.h>
#include<unistd.h>

void time();

int sec=0;

int main()
{	
	signal(SIGINT,time);
	printf("you can't stop me!\n");
	while(1)
	{
		sleep(1);
		printf("haha\n");
		sec++;
	}
	return 0;
}

void time()
{
	printf("Currently elapsed time: %d sec(s)\n",sec);
}
