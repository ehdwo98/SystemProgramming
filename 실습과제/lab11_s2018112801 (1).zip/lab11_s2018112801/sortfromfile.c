#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/wait.h>

int main(int acgc, char **argv)
{
	int	pid ;
	int	fd;

	printf("About to run who into a file\n");

	if( (pid = fork() ) == -1 ){
		perror("fork"); exit(1);
	}
	if ( pid == 0 ){
		fd = open( argv[1], O_RDONLY, 0644);
		dup2(fd, 0);
		execlp( "sort", "sort", NULL );
		perror("execlp");
		close(fd);
		exit(1);
	}
	if ( pid != 0 ){
		wait(NULL);
		printf("Done running < %s\n", argv[1]);
	}
	return 0;
}
