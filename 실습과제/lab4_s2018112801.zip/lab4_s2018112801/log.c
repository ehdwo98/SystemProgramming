Starting program: /home/VDI-KNU/2018112801_14778/lab4_s2018112801/ls1 
[Inferior 1 (process 82320) exited normally]
Breakpoint 1 at 0x5555555552a4: file ls1.c, line 27.
Breakpoint 2 at 0x55555555524c: file ls1.c, line 19.
The program is not being run.
Starting program: /home/VDI-KNU/2018112801_14778/lab4_s2018112801/ls1 arg1

Breakpoint 2, do_ls (
    dirname=0x55555555531d <__libc_csu_init+77> "H\203\303\001H9\335u\352H\203\304\b[]A\\A]A^A_\303ff.\017\037\204") at ls1.c:19
19	{	
Continuing.
[Inferior 1 (process 82330) exited with code 026]
The program is not being run.
$1 = {void (int, char **)} 0x5555555551e9 <main>
