#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <pthread.h>
#include <ctype.h>


int total_word;
pthread_mutex_t counter_lock = PTHREAD_MUTEX_INITIALIZER;


int main(int ac, char* av[])

{

        pthread_t t1,t2;

        void *count_word(void*);

        if(ac!=3)

        {
                printf("usage");
                exit(1);
        }

        total_word = 0;
        pthread_create(&t1,NULL,count_word,(void*)av[1]);
        pthread_create(&t2,NULL,count_word,(void*)av[2]);
        pthread_join(t1,NULL);
        pthread_join(t2,NULL);
        printf("%5d: total word\n", total_word);
}

void *count_word(void* f)
{
        char* filename = (char*) f;
        FILE *fp;
        int c, prevc = '\0';

        if ((fp=fopen(filename, "r"))!= NULL)
        {
                while((c=getc(fp))!=EOF)
                {
                        if(!isalnum(c)&&isalnum(prevc))
                        {
                                pthread_mutex_lock(&counter_lock);
                                total_word++;
                                pthread_mutex_unlock(&counter_lock);
                        }
                        prevc = c;
                }
                fclose(fp);
        }
        else
                perror(filename);

        return NULL;
}
