#include <stdio.h>
#include <string.h>


#define PAST 0
#define PRESENT 1

int main()
{

    	char cpuID[10] = {0};
    	double diffjiffies[5][5] = {0};
    	double jiffies[2][5][5] = {0};
    	double totaljiffies;
    	
    	double mem[5]={0};
	char memid[10]={0};
	
	char* intrpName[5]={"0"};
	int intrpID[5]={0};
	int intrpCalling[5]={0};
	
	FILE* statFile;
	FILE* memFile;
	FILE* intrpFile;
	
	while(1){
	totaljiffies = 0;
	
        statFile = fopen("/proc/stat", "r");
        
        printf("               ID   usr  nice  sys  idle\n");
        for(int i = 0; i < 5; i++){
            fscanf(statFile,"%s %lf %lf %lf %lf",cpuID, &jiffies[PRESENT][i][0], &jiffies[PRESENT][i][1], &jiffies[PRESENT][i][2], &jiffies[PRESENT][i][3], &jiffies[PRESENT][i][4]);
            
            for(int j = 0; j < 5; j++){
                diffjiffies[i][j] = jiffies[PRESENT][i][j]-jiffies[PAST][i][j];
                jiffies[PAST][i][j] = jiffies[PRESENT][i][j];
                totaljiffies += diffjiffies[i][j];
            	}
            
            printf("CPU usage : %5s %4.2lf  %4.2lf  %4.2lf  %4.2lf\n",cpuID, 100 * (diffjiffies[i][0]/totaljiffies), 100 * (diffjiffies[i][1]/totaljiffies), 100 * (diffjiffies[i][2]/totaljiffies), 100 * (diffjiffies[i][3]/totaljiffies), 100 * (diffjiffies[i][4]/totaljiffies)); 
            
            }
            
        printf("\n");
        fclose(statFile);
        
        memFile = fopen("/proc/meminfo", "r");
        printf("MemTotal   MemFree   MemAvail   Buffers   Cached\n");
         for(int i = 0; i < 5; i++){
             fscanf(memFile,"%s %lf", memid, &mem[i]);
         }
	 printf("%5.5lf %5.5lf %5.5lf %5.5lf %5.5lf\n", mem[0]/1024,mem[1]/1024,mem[2]/1024,mem[3]/1024,mem[4]/1024);
        
        printf("\n");
        fclose(memFile);
        
        intrpFile = fopen("/proc/interrupts", "r");
        printf("unpiqueID   Calling    name\n");
        for(int i = 0; i <5; i++){
        	fscanf(intrpFile,"%d %d %s", &intrpID[i],&intrpCalling[i], intrpName[i]);
        	printf("%5d :  %5d   %10s\n",intrpID[i],intrpCalling[i], intrpName[i]);
        }
        printf("------------------------------------------------------------\n");
        fclose(intrpFile);
        
        sleep(1);
    }
    return 0;
}
